USE CompanyDB
GO

SELECT * FROM Employees;

SELECT 
    FirstName,
    LastName, 
    Salary
FROM Employees;

SELECT 
    FirstName + ' ' + LastName AS FullName,
    Salary,
    HireDate
FROM Employees
WHERE Salary > 70000
ORDER BY Salary DESC;

SELECT 
    e.FirstName,
    e.LastName,
    e.Salary,
    d.DepartmentName
FROM Employees e
INNER JOIN Departments d ON e.DepartmentID = d.DepartmentID
WHERE d.DepartmentName = 'IT';

SELECT 
    d.DepartmentName,
    COUNT(e.EmployeeID) AS EmployeeCount,
    AVG(e.Salary) AS AverageSalary
FROM Departments d
LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID
GROUP BY d.DepartmentName
ORDER BY EmployeeCount DESC;

SELECT 
    ProjectName,
    StartDate,
    EndDate,
    Budget,
    Status
FROM Projects
WHERE Status = 'Active' AND EndDate IS NOT NULL;