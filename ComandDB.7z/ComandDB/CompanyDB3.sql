USE CompanyDB;
GO

UPDATE Employees
SET Salary = Salary * 1.10
WHERE DepartmentID = (SELECT DepartmentID FROM Departments WHERE DepartmentName = 'IT');

SELECT * FROM Employees WHERE DepartmentID = 1;

UPDATE Projects
SET Status = 'Completed', EndDate = GETDATE()
WHERE ProjectName = '���������� ��������' AND Status = 'Active';


UPDATE Employees
SET DepartmentID = (SELECT DepartmentID FROM Departments WHERE DepartmentName = 'Marketing')
WHERE DepartmentID IS NULL;

UPDATE Departments
SET Budget = Budget + 50000.00
WHERE DepartmentName = 'Sales';


UPDATE Employees
SET Email = 'ivanov.new@company.com'
WHERE FirstName = '����' AND LastName = '������';

UPDATE Employees
SET DepartmentID = (SELECT DepartmentID FROM Departments WHERE DepartmentName = 'Finance')
WHERE FirstName = '�����' AND LastName = '�������';