USE CompanyDB
GO

BEGIN TRANSACTION;

INSERT INTO Departments (DepartmentName, Location, Budget)
VALUES ('Research & Development', '6 ����', 450000.00);

DECLARE @NewDeptID INT = SCOPE_IDENTITY();

INSERT INTO Employees (FirstName, LastName, Email, Phone, HireDate, Salary, DepartmentID)
VALUES ('����', '��������', 'novikova@company.com', '+7(999)678-90-12', GETDATE(), 78000.00, @NewDeptID);

COMMIT TRANSACTION;

UPDATE Employees
SET Salary = 
    CASE 
        WHEN DepartmentID = 1 THEN Salary * 1.15 -- IT +15%
        WHEN DepartmentID = 5 THEN Salary * 1.10 -- Sales +10%
        ELSE Salary * 1.05 -- ��� ��������� +5%
    END;

SELECT DepartmentID 
INTO #DeptsToDelete
FROM Departments 
WHERE DepartmentName IN ('Temp Department', 'Old Department');


DELETE FROM Employees 
WHERE DepartmentID IN (SELECT DepartmentID FROM #DeptsToDelete);


DELETE FROM Departments 
WHERE DepartmentID IN (SELECT DepartmentID FROM #DeptsToDelete);


DROP TABLE #DeptsToDelete;


SELECT *
INTO ProjectsArchive
FROM Projects
WHERE Status = 'Completed';


UPDATE Projects
SET 
    Status = 'On Hold',
    Budget = Budget * 0.9
WHERE EndDate IS NULL AND DATEDIFF(MONTH, StartDate, GETDATE()) > 6;


SELECT 
    'Employees' AS TableName, 
    COUNT(*) AS RecordCount 
FROM Employees
UNION ALL
SELECT 'Departments', COUNT(*) FROM Departments
UNION ALL
SELECT 'Projects', COUNT(*) FROM Projects
UNION ALL
SELECT 'ProjectsArchive', COUNT(*) FROM ProjectsArchive;